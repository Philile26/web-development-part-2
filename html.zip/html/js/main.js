// ==========================================================================
// FILENAME: js/main.js
// PURPOSE: Master JavaScript Framework for Soweto Commuter Hub
// FEATURES: Client-Side Validation, Search/Filter Engine, UI Accordions & Lightbox
// ==========================================================================

document.addEventListener("DOMContentLoaded", () => {

    /* ==========================================================================
       1. FORM VALIDATION ENGINE (Enquiry & Contact Forms)
       ========================================================================== */
    
    // --- ENQUIRY FORM HANDLING ---
    const enquiryForm = document.getElementById("enquiryForm");
    if (enquiryForm) {
        enquiryForm.addEventListener("submit", (e) => {
            e.preventDefault(); // Prevent standard page reload
            
            if (validateForm(enquiryForm)) {
                // Simulate asynchronous background processing (AJAX)
                const submitBtn = enquiryForm.querySelector("button[type='submit']");
                submitBtn.disabled = true;
                submitBtn.textContent = "Processing Async Submission...";
                
                setTimeout(() => {
                    submitBtn.disabled = false;
                    submitBtn.textContent = "Submit Enquiry";
                    
                    // Display dynamic output response back to the commuter
                    const responseContainer = document.getElementById("enquiryResponse");
                    if (responseContainer) {
                        const categorySelect = document.getElementById("category");
                        const selectedText = categorySelect ? categorySelect.options[categorySelect.selectedIndex].text : "your selection";
                        
                        responseContainer.innerHTML = `
                            <div class="status-alert" style="background-color: #d4edda; border-color: #c3e6cb; color: #155724; padding: 1rem; border-radius: 4px; margin-top: 1rem;">
                                <h3>Enquiry Received Successfully!</h3>
                                <p>Thank you for reaching out regarding <strong>${selectedText}</strong>. A customized pricing tier matrix and transit availability guide has been dispatched to your information cache.</p>
                            </div>
                        `;
                        enquiryForm.reset();
                    }
                }, 1200); 
            }
        });
    }

    // --- CONTACT FORM HANDLING ---
    const contactForm = document.getElementById("contactForm");
    if (contactForm) {
        contactForm.addEventListener("submit", (e) => {
            e.preventDefault();
            
            if (validateForm(contactForm)) {
                const name = document.getElementById("name").value;
                const email = document.getElementById("email").value;
                const message = document.getElementById("message").value;
                
                // Requirement 2.3: Compile data fields into a client-side mailto link
                const emailRecipient = "organisation@example.com";
                const subject = encodeURIComponent(`Soweto Hub Contact from ${name}`);
                const body = encodeURIComponent(`Commuter Name: ${name}\nEmail: ${email}\n\nMessage:\n${message}`);
                
                // Open system email client
                window.location.href = `mailto:${emailRecipient}?subject=${subject}?body=${body}`;
                contactForm.reset();
            }
        });
    }

    // --- REUSABLE VALIDATION LOGIC ---
    function validateForm(form) {
        let isFormValid = true;
        const requiredInputs = form.querySelectorAll("input[required], select[required], textarea[required]");
        
        requiredInputs.forEach(input => {
            // Reset existing validation styles
            input.classList.remove("input-error");
            const existingError = input.parentElement.querySelector(".error-message");
            if (existingError) existingError.remove();
            
            // Check for empty values
            if (!input.value.trim()) {
                showFieldError(input, "This field cannot be left blank.");
                isFormValid = false;
            } 
            // Check for valid email formatting
            else if (input.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value)) {
                showFieldError(input, "Please provide a valid email format.");
                isFormValid = false;
            }
        });
        
        return isFormValid;
    }

    function showFieldError(input, alertText) {
        input.classList.add("input-error"); // Applies red borders from your updated style.css
        
        const errorElement = document.createElement("span");
        errorElement.className = "error-message";
        errorElement.style.color = "#dc3545";
        errorElement.style.fontSize = "0.85rem";
        errorElement.style.fontWeight = "600";
        errorElement.textContent = alertText;
        
        input.parentElement.appendChild(errorElement);
    }


    /* ==========================================================================
       2. DYNAMIC CONTENT ENGINE: SEARCH, FILTER, AND SORT (`services.html`)
       ========================================================================== */
    const dynamicGrid = document.getElementById("dynamicGrid");
    const catalogueSearch = document.getElementById("catalogueSearch");
    const categoryFilter = document.getElementById("categoryFilter");
    const sortOrder = document.getElementById("sortOrder");

    // Dynamic Data Array Object Matrices
    const servicesData = [
        { id: 1, title: "Local Commuter Transit Shuttles", category: "commuter", price: 15, desc: "High-frequency internal loops traveling across local zones (e.g., Jabulani, Meadowlands, Orlando)." },
        { id: 2, title: "Long-Distance Economic Hub Routes", category: "commuter", price: 32, desc: "Direct peak-hour express lines linking Soweto ranks directly to Johannesburg CBD, Sandton, and Randburg." },
        { id: 3, title: "Funeral & Church Group Charters", category: "charter", price: 1200, desc: "Respectful, planned, and punctual private minibus allocation services for religious congregations and families." },
        { id: 4, title: "Stadium & Entertainment Event Shuttles", category: "charter", price: 85, desc: "Round-trip luxury transit clusters straight to FNB Stadium and Orlando Stadium on major matchdays." },
        { id: 5, title: "Rank-to-Rank Rapid Parcel Delivery", category: "courier", price: 45, desc: "Drop secure parcels off at any verified rank hub management counter for delivery across town in hours." }
    ];

    if (dynamicGrid) {
        function renderCatalogue(items) {
            dynamicGrid.innerHTML = ""; // Flush content container
            
            if (items.length === 0) {
                dynamicGrid.innerHTML = `<p class="card alert-card">No operations or service tiers match your current search constraints.</p>`;
                return;
            }

            items.forEach(item => {
                const card = document.createElement("div");
                card.className = "card";
                card.innerHTML = `
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem;">
                        <h3>${item.title}</h3>
                        <span style="background: var(--secondary-color); color: #fff; padding: 0.2rem 0.6rem; font-size: 0.75rem; border-radius: 4px; font-weight: bold; text-transform: uppercase;">${item.category}</span>
                    </div>
                    <p style="margin: 0.5rem 0; color: var(--text-muted);">${item.desc}</p>
                    <p style="font-weight: 700; color: var(--accent-color);">Base Rate Matrix: ${item.price === 1200 ? 'From R1200' : 'R' + item.price + '.00'}</p>
                `;
                dynamicGrid.appendChild(card);
            });
        }

        function processCatalogue() {
            let processed = [...servicesData];

            // Keyword Search Processing
            const query = catalogueSearch.value.toLowerCase().trim();
            if (query) {
                processed = processed.filter(item => 
                    item.title.toLowerCase().includes(query) || 
                    item.desc.toLowerCase().includes(query)
                );
            }

            // Category Filter Dropdown Matching
            const filterValue = categoryFilter.value;
            if (filterValue !== "all") {
                processed = processed.filter(item => item.category === filterValue);
            }

            // Pricing & Alphanumeric Sort Sorting
            const sortingValue = sortOrder.value;
            if (sortingValue === "price-low-high") {
                processed.sort((a, b) => a.price - b.price);
            } else if (sortingValue === "price-high-low") {
                processed.sort((a, b) => b.price - a.price);
            } else if (sortingValue === "title-az") {
                processed.sort((a, b) => a.title.localeCompare(b.title));
            }

            renderCatalogue(processed);
        }

        // Add real-time event tracking loops
        catalogueSearch.addEventListener("input", processCatalogue);
        categoryFilter.addEventListener("change", processCatalogue);
        sortOrder.addEventListener("change", processCatalogue);

        // Run baseline render deployment
        renderCatalogue(servicesData);
    }


    /* ==========================================================================
       3. INTERACTIVE COMPONENT MECHANICS (Accordions & Lightbox Overlay)
       ========================================================================== */
    
    // --- ACCORDION EXPANSION CODE ---
    const accordionHeaders = document.querySelectorAll(".accordion-header");
    accordionHeaders.forEach(header => {
        header.style.cursor = "pointer";
        header.addEventListener("click", () => {
            const body = header.nextElementSibling;
            if (body && body.classList.contains("accordion-body")) {
                const isOpen = body.style.display === "block";
                
                // Hide existing matching spaces
                document.querySelectorAll(".accordion-body").forEach(b => b.style.display = "none");
                
                body.style.display = isOpen ? "none" : "block";
            }
        });
    });

    // --- LIGHTBOX GALLERY POP-UP MODAL ---
    const galleryThumbs = document.querySelectorAll(".gallery-thumb");
    if (galleryThumbs.length > 0) {
        // Construct dynamic full-screen overlay component interface
        const lightboxOverlay = document.createElement("div");
        lightboxOverlay.style.cssText = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.85); z-index:2000; display:none; justify-content:center; align-items:center; cursor:zoom-out;";
        
        const lightboxImg = document.createElement("img");
        lightboxImg.style.cssText = "max-width:85%; max-height:85%; border: 3px solid #fff; border-radius:4px; box-shadow:0 0 25px rgba(0,0,0,0.5); cursor:default;";
        
        lightboxOverlay.appendChild(lightboxImg);
        document.body.appendChild(lightboxOverlay);

        galleryThumbs.forEach(thumb => {
            thumb.addEventListener("click", () => {
                lightboxImg.src = thumb.src;
                lightboxImg.alt = thumb.alt;
                lightboxOverlay.style.display = "flex";
            });
        });

        lightboxOverlay.addEventListener("click", (e) => {
            if (e.target !== lightboxImg) {
                lightboxOverlay.style.display = "none";
            }
        });
    }
});